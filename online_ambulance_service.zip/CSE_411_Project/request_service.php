<?php require_once("connection.php"); ?>
<?php
	$q="SELECT * FROM `hospital_list`";
	$result=mysqli_query($conn,$q);
	$q1="SELECT * FROM `type_of_ambulance`";
	$result1=mysqli_query($conn,$q1);
	if(isset($_POST['Reserve'])){
		$user_name=$_POST['user_name'];
		$Hospital_name=$_POST['Hospital_name'];
		$ambulance_name=$_POST['ambulance_name'];
		$pickup=$_POST['pickup'];
		$verification_key=md5(time().$user_name);
		$INSERT= "INSERT Into reservation (user_name,Hospital_name,ambulance_name,pickup,verification_key) values(?,?,?,?,?)";
		$stmt=$conn->prepare($INSERT);
		$stmt->bind_param("sssss", $user_name,$Hospital_name,$ambulance_name,$pickup,$verification_key);
		$stmt->execute();
		$query_info1="SELECT * FROM `service_recipient`";
		$result_info1=mysqli_query($conn,$query_info1);
		while($row2=mysqli_fetch_array($result_info1)){
			if($row2[1]==$user_name){
				$email_g=$row2[2];
				$phn=$row2[3];
			}
		}
		$query_m="SELECT * FROM `service_provider`";
      	$result_m=mysqli_query($conn,$query_m);
      	while($row2=mysqli_fetch_array($result_m)){
      	$email=$row2[2];
      	$to= $email;
      	$subject= "New Trip";

      	$message="
      			 Service Receiver: $user_name
      			 Service Receiver Email: $email_g
      			 Service Receiver Number: $phn
      			 Hospital: $Hospital_name
      			 Pickup Location: $pickup
      	<a href=http://localhost:8010/CSE_411_Project/reservation_call.php?verification_key=$verification_key>Click on the link if you want to take this trip?</a>";
     	$headers="From: abirjubayer487625@gmail.com";
     	mail($to,$subject,$message,$headers);
      }

	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content= "width=device-width">
	<title>Online Ambulance Service | Welcome</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
	<link rel="stylesheet" href="./CSS/style.css">
	<style>
    	*{margin:0px; padding:0px; }
    	#container{width:300px; margin:0px auto;}
    	.input{width:92%;padding:2%;}
	</style>
</head>
<body>
	
	<header>
		<div class="container">
			<div id="branding">
				<h1><span class="highlight">Online Ambulance Service</span></h1>
			</div>
			<nav>
					<ul>
						<li><a href="home.php">Home</a></li>
						<li class="current"><a href="request_service.php">Reservation</a></li>
            <li><a href="messages.php">Inbox</a></li>
						<li><a href="add_rate.php">System Rating</a></li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
			</nav>
		</div>
	</header>
	<body>
		<h1 align="center">Reservation</h1>
		<div id="container">
    		<form method="post">
            	<input type="text" placeholder="User Name" name="user_name" class="input" required /><br><br>
            	<label>Please Select Hospital: </label>
            	<select name="Hospital_name" class="input">
            		<?php while($row=mysqli_fetch_array($result)):;?>
            		<option value="<?php echo $row[1];?>"><?php echo $row[1];?></option>
            		<?php endwhile; ?>

            	</select><br><br>

            	<label>Please Select Ambulance: </label>
            	<select name="ambulance_name" class="input">
            		<?php while($row=mysqli_fetch_array($result1)):;?>
            		<option value="<?php echo $row[1];?>"><?php echo $row[1];?></option>
            		<?php endwhile; ?>

            	</select><br><br>

            	<input type="text" placeholder="Enter Pickup Location" name="pickup" class="input" required /><br><br>
     			<input type="submit" id ="Reserve" name="Reserve" value="Reserve" />
    		</form>
		</div>
	</body>
</html>



