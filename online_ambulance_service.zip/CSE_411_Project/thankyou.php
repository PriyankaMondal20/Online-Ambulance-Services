<?php

	echo "Thank you for registration. We have sent a verification email to the address provided.";
?>