<?php require_once("connection.php"); ?>

<?php
	if(isset($_GET['email'])){
		$email=$_GET['email'];
		$query_info1="SELECT * FROM `service_recipient`";
		$result_info1=mysqli_query($conn,$query_info1);
		while($row2=mysqli_fetch_array($result_info1)){
			if($row2[2]==$email){
				$user_name=$row2[1];
			}
		}
		$query_info2="SELECT * FROM `reservation`";
		$result_info2=mysqli_query($conn,$query_info2);
		while($row2=mysqli_fetch_array($result_info2)){
			if($row2[1]==$user_name){
				$verification_key=$row2[5];
			}
		}
		$SELECT="SELECT verified, verification_key FROM reservation where verified = 1 AND verification_key='$verification_key' LIMIT 1";
		$resultSet= mysqli_query($conn,$SELECT);
		if($resultSet->num_rows ==1){
		//validate the email
		 	$UPDATE= "UPDATE reservation SET verified = -1 WHERE verification_key = '$verification_key' LIMIT 1";
			 $update=mysqli_query($conn,$UPDATE);
		 	if($update){
		 		echo "Your trip has been canceled";
			}
			else{
				echo "This account is invalid or already verified";
			}
		}
		else{
			echo "I don't know";
		}
	}
	else{
		die("Something Went Wrong");
	}

?>