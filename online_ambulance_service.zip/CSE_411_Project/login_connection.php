<?php 
session_start();
require_once("connection.php"); 
?>
<?php

	if(isset($_POST['Login'])){
		$User=$_POST['User'];
        $user_name = $_POST['user_name'];
        $password=$_POST['password'];
        if($User=='Admin'&&$user_name='Admin'&&$password=='Admin'){
			$_SESSION['user_name']=$user_name;
				header("Location: home_admin.php");
		}
		$user_name=mysqli_real_escape_string($conn, $_POST['user_name']);
		$password=mysqli_real_escape_string($conn,$_POST['password']);
		$password=md5($password);
		$sql= "SELECT * FROM service_recipient WHERE user_name='$user_name' AND '$password'";
		$query=mysqli_query($conn, $sql);
		$result=mysqli_num_rows($query);
		$sql1= "SELECT * FROM service_provider WHERE user_name='$user_name' AND '$password'";
		$query1=mysqli_query($conn, $sql1);
		$result1=mysqli_num_rows($query1);
		$sql2= "SELECT * FROM admin WHERE user_name='$user_name' AND '$password'";
		$query2=mysqli_query($conn, $sql2);
		$result2=mysqli_num_rows($query2);
		if($result>0&&$User=='Service_Receiver'){
			$_SESSION['user_name']=$user_name;
				header("Location: home.php");
		}
		elseif($result1>0&&$User=='Service_Provider'){
			$_SESSION['user_name']=$user_name;
				header("Location: home_provider.php");
		}
		else{
			echo '<a href="service_recipient.php">Register as a Service Recipient</a>';
			echo "<br/>";
			echo "<br/>";
			echo '<a href="service_provider.html">Register as a Service Provider</a>';
		}
	}
			
?>

