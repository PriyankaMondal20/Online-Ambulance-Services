<?php require_once("connection.php");?>
<?php
	session_start();
	if(isset($_SESSION['user_name'])){
		//
	}
?>

<!DOCTYPE html>
<html>
<style>
	<?php require_once("js/style.php");?>
	
</style>

<body>
	<?php require_once("js/new-message.php"); ?>
	<div id="container">
		<div id="menu">
			<?php 
				echo $_SESSION['user_name'];
			?>
		</div>
		<div id="left-col">
			
			<?php require_once("js/left-col.php"); ?>

		<!--end of left column-->
		</div>
		<div id="right-col">
			<?php require_once("js/right-col.php"); ?>
			<!--end of right column-->
		</div>
	</div>
</body>
</html>		