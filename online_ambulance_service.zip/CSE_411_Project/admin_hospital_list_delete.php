<?php require_once("connection.php");?>
<?php

			if(!$conn){
				die('server not connected');
			}
			$query= "DELETE from hospital_list where id='$_GET[id]'";
			$r= mysqli_query($conn,$query);
			if(mysqli_query($conn,$query)){
				header("refresh:1;url=admin_hospital_list.php");
			}
			else{
				echo "Not deleted";
			}





?>